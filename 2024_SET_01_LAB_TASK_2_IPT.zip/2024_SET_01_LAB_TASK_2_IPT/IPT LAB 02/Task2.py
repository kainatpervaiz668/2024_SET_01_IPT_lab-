# Input image dimensions
width = int(input("Enter image width in pixels: "))
height = int(input("Enter image height in pixels: "))

# Calculate total pixels
total_pixels = width * height

# Display result
print("Total Pixels:", total_pixels)
