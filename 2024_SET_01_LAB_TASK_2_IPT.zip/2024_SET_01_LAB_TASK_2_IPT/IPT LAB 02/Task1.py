# Input two numbers
num1 = float(input("Enter first number: "))
num2 = float(input("Enter second number: "))

# Perform calculations
sum_result = num1 + num2
difference = num1 - num2
product = num1 * num2

# Display results
print("Sum:", sum_result)
print("Difference:", difference)
print("Product:", product)

if num2 != 0:
    print("Division:", num1 / num2)
else:
    print("Division is not possible because the second number is zero.")
