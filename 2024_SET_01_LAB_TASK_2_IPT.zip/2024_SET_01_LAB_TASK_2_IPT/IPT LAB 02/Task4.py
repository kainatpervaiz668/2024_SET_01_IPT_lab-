# Input student information
name = input("Enter student name: ")
roll_number = input("Enter roll number: ")

# Input marks in three subjects
marks1 = float(input("Enter marks in Subject 1: "))
marks2 = float(input("Enter marks in Subject 2: "))
marks3 = float(input("Enter marks in Subject 3: "))

# Calculate total and average
total = marks1 + marks2 + marks3
average = total / 3

# Display student information
print("\n--- Student Information ---")
print("Name:", name)
print("Roll Number:", roll_number)
print("Marks in Subject 1:", marks1)
print("Marks in Subject 2:", marks2)
print("Marks in Subject 3:", marks3)
print("Total Marks:", total)
print("Average Marks:", average)
