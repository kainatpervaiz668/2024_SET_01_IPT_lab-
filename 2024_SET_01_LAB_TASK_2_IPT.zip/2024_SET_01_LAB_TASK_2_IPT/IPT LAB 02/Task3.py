width = int(input("Enter image width in pixels: "))
height = int(input("Enter image height in pixels: "))

total_pixels = width * height
size_bytes = total_pixels
size_kb = size_bytes / 1024

print("Total Pixels:", total_pixels)
print("Image Size in Bytes:", size_bytes)
print("Image Size in Kilobytes:", size_kb, "KB")

